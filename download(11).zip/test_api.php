<?php
/**
 * Simple test script to verify the API works with different formats
 * Run this from the command line: php test_api.php
 */

$baseUrl = 'http://localhost';
$testUrl = 'https://www.example.com';

echo "========================================\n";
echo "Testing URL Shortener API\n";
echo "========================================\n\n";

// Test 1: JSON format (default)
echo "Test 1: JSON format\n";
echo "-------------------\n";
$url = $baseUrl . '/api?url=' . urlencode($testUrl);
echo "Request: $url\n";
$response = @file_get_contents($url);
echo "Response: $response\n\n";

// Test 2: Simple format
echo "Test 2: Simple format\n";
echo "---------------------\n";
$url = $baseUrl . '/api?format=simple&url=' . urlencode($testUrl);
echo "Request: $url\n";
$response = @file_get_contents($url);
echo "Response: $response\n\n";

// Test 3: XML format
echo "Test 3: XML format\n";
echo "------------------\n";
$url = $baseUrl . '/api?format=xml&url=' . urlencode($testUrl);
echo "Request: $url\n";
$response = @file_get_contents($url);
echo "Response: $response\n\n";

// Test 4: Custom short URL
echo "Test 4: Custom short URL (JSON)\n";
echo "--------------------------------\n";
$customCode = 'test' . rand(1000, 9999);
$url = $baseUrl . '/api?url=' . urlencode($testUrl) . '&shorturl=' . $customCode;
echo "Request: $url\n";
$response = @file_get_contents($url);
echo "Response: $response\n\n";

// Test 5: JSONP with callback
echo "Test 5: JSONP with callback\n";
echo "---------------------------\n";
$url = $baseUrl . '/api?url=' . urlencode($testUrl) . '&callback=myCallback';
echo "Request: $url\n";
$response = @file_get_contents($url);
echo "Response: $response\n\n";

// Test 6: Error - missing URL
echo "Test 6: Error handling - missing URL\n";
echo "------------------------------------\n";
$url = $baseUrl . '/api';
echo "Request: $url\n";
$response = @file_get_contents($url);
echo "Response: $response\n\n";

// Test 7: Error - invalid URL
echo "Test 7: Error handling - invalid URL (simple format)\n";
echo "-----------------------------------------------------\n";
$url = $baseUrl . '/api?format=simple&url=notavalidurl';
echo "Request: $url\n";
$response = @file_get_contents($url);
echo "Response: $response\n\n";

echo "========================================\n";
echo "All tests completed!\n";
echo "========================================\n";
