<?php
/* ================= DB CONFIG ================= */
$db_host = "sql312.infinityfree.com";
$db_user = "if0_40729134";
$db_pass = "JBPPirGR2jDFNP";
$db_name = "if0_40729134_urls";
/* ============================================= */

/* ===== AUTO BASE URL ===== */
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
$base_url = $scheme . "://" . $_SERVER['HTTP_HOST'];

/* ===== CONNECT ===== */
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) die("Database error");

/* ===== TABLES (AUTO CREATE) ===== */
$conn->query("
CREATE TABLE IF NOT EXISTS links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(32) UNIQUE,
    url TEXT NOT NULL,
    clicks INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$conn->query("
CREATE TABLE IF NOT EXISTS click_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    link_id INT,
    day DATE,
    clicks INT DEFAULT 1,
    UNIQUE(link_id, day)
)");

/* ===== HELPERS ===== */
function random_slug($len = 6) {
    return substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, $len);
}

function get_domain_from_url($url) {
    $parsed = parse_url($url);
    $host = $parsed['host'] ?? '';
    if (strpos($host, 'www.') === 0) {
        $host = substr($host, 4);
    }
    return $host;
}

function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

/* ===== PUBLIC API ENDPOINTS at /api ===== */
$path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), "/");

// Handle /api endpoint
if (strpos($path, 'api') === 0) {
    // Handle CORS preflight requests
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        json_response(['success' => true]);
    }
    
    $method = $_SERVER['REQUEST_METHOD'];
    $api_path = substr($path, 4); // Remove 'api/' from path
    
    // Parse the API path
    $parts = explode('/', $api_path);
    $endpoint = $parts[0] ?? '';
    $param = $parts[1] ?? '';
    
    switch($endpoint) {
        case 'create':
            // GET /api/create?url=https://example.com&slug=optional
            // POST /api/create (with JSON or form data)
            if ($method === 'GET') {
                // Handle GET request
                $url = $_GET['url'] ?? '';
                $custom_slug = $_GET['slug'] ?? '';
                
                if (!$url) {
                    json_response(['error' => 'URL parameter is required. Use ?url=https://example.com'], 400);
                }
            } elseif ($method === 'POST') {
                // Handle POST request
                $content_type = $_SERVER['CONTENT_TYPE'] ?? '';
                
                if (strpos($content_type, 'application/json') !== false) {
                    $input = json_decode(file_get_contents('php://input'), true);
                } else {
                    $input = $_POST;
                }
                
                $url = $input['url'] ?? '';
                $custom_slug = $input['slug'] ?? '';
            } else {
                json_response(['error' => 'Method not allowed. Use GET or POST.'], 405);
            }
            
            if (!$url) {
                json_response(['error' => 'URL is required'], 400);
            }
            
            if (!filter_var($url, FILTER_VALIDATE_URL)) {
                json_response(['error' => 'Invalid URL format'], 400);
            }
            
            if ($custom_slug) {
                if (!preg_match("/^[a-zA-Z0-9_-]+$/", $custom_slug)) {
                    json_response(['error' => 'Invalid slug format. Use only letters, numbers, hyphens and underscores.'], 400);
                }
                $slug = $custom_slug;
            } else {
                do {
                    $slug = random_slug();
                    $check = $conn->query("SELECT id FROM links WHERE slug='$slug'");
                } while ($check->num_rows > 0);
            }
            
            $stmt = $conn->prepare("INSERT INTO links (slug, url) VALUES (?, ?)");
            $stmt->bind_param("ss", $slug, $url);
            
            if (!$stmt->execute()) {
                json_response(['error' => 'Slug already exists'], 409);
            }
            
            json_response([
                'success' => true,
                'method' => $method,
                'slug' => $slug,
                'short_url' => $base_url . '/' . $slug,
                'preview_url' => $base_url . '/' . $slug . '+',
                'destination' => $url,
                'api_url' => $base_url . '/api/info/' . $slug
            ]);
            break;
            
        case 'info':
            // GET /api/info/:slug or /api/info?slug=abc123
            if ($method !== 'GET') {
                json_response(['error' => 'Method not allowed. Use GET.'], 405);
            }
            
            if (!$param) {
                $slug = $_GET['slug'] ?? '';
            } else {
                $slug = $param;
            }
            
            if (!$slug) {
                json_response(['error' => 'Slug is required'], 400);
            }
            
            $stmt = $conn->prepare("SELECT * FROM links WHERE slug = ?");
            $stmt->bind_param("s", $slug);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                json_response(['error' => 'Link not found'], 404);
            }
            
            $link = $result->fetch_assoc();
            
            // Get stats for last 30 days
            $stats_stmt = $conn->prepare("
                SELECT day, SUM(clicks) as clicks 
                FROM click_stats 
                WHERE link_id = ? 
                GROUP BY day 
                ORDER BY day DESC 
                LIMIT 30
            ");
            $stats_stmt->bind_param("i", $link['id']);
            $stats_stmt->execute();
            $stats_result = $stats_stmt->get_result();
            $daily_stats = [];
            while ($row = $stats_result->fetch_assoc()) {
                $daily_stats[] = $row;
            }
            
            json_response([
                'slug' => $link['slug'],
                'destination' => $link['url'],
                'short_url' => $base_url . '/' . $link['slug'],
                'preview_url' => $base_url . '/' . $link['slug'] . '+',
                'total_clicks' => (int)$link['clicks'],
                'created_at' => $link['created_at'],
                'daily_stats' => $daily_stats
            ]);
            break;
            
        case 'stats':
            // GET /api/stats/:slug or /api/stats?slug=abc123
            if ($method !== 'GET') {
                json_response(['error' => 'Method not allowed. Use GET.'], 405);
            }
            
            if (!$param) {
                $slug = $_GET['slug'] ?? '';
            } else {
                $slug = $param;
            }
            
            if (!$slug) {
                json_response(['error' => 'Slug is required'], 400);
            }
            
            $stmt = $conn->prepare("SELECT * FROM links WHERE slug = ?");
            $stmt->bind_param("s", $slug);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                json_response(['error' => 'Link not found'], 404);
            }
            
            $link = $result->fetch_assoc();
            
            // Get detailed stats
            $stats_stmt = $conn->prepare("
                SELECT day, clicks 
                FROM click_stats 
                WHERE link_id = ? 
                ORDER BY day
            ");
            $stats_stmt->bind_param("i", $link['id']);
            $stats_stmt->execute();
            $stats_result = $stats_stmt->get_result();
            $daily_stats = [];
            while ($row = $stats_result->fetch_assoc()) {
                $daily_stats[] = $row;
            }
            
            // Calculate totals
            $total_clicks = (int)$link['clicks'];
            $today_clicks = 0;
            $today = date('Y-m-d');
            foreach ($daily_stats as $stat) {
                if ($stat['day'] == $today) {
                    $today_clicks = $stat['clicks'];
                    break;
                }
            }
            
            json_response([
                'slug' => $link['slug'],
                'destination' => $link['url'],
                'total_clicks' => $total_clicks,
                'today_clicks' => $today_clicks,
                'created_at' => $link['created_at'],
                'daily_stats' => $daily_stats
            ]);
            break;
            
        case 'redirect':
            // GET /api/redirect/:slug - Returns redirect data without actually redirecting
            if ($method !== 'GET') {
                json_response(['error' => 'Method not allowed. Use GET.'], 405);
            }
            
            if (!$param) {
                $slug = $_GET['slug'] ?? '';
            } else {
                $slug = $param;
            }
            
            if (!$slug) {
                json_response(['error' => 'Slug is required'], 400);
            }
            
            $stmt = $conn->prepare("SELECT * FROM links WHERE slug = ?");
            $stmt->bind_param("s", $slug);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                json_response(['error' => 'Link not found'], 404);
            }
            
            $link = $result->fetch_assoc();
            
            // Increment click counter
            $conn->query("UPDATE links SET clicks = clicks + 1 WHERE id={$link['id']}");
            $today = date("Y-m-d");
            $conn->query("
            INSERT INTO click_stats (link_id, day, clicks)
            VALUES ({$link['id']}, '$today', 1)
            ON DUPLICATE KEY UPDATE clicks = clicks + 1
            ");
            
            json_response([
                'redirect' => true,
                'location' => $link['url'],
                'status' => 302,
                'slug' => $link['slug'],
                'total_clicks' => (int)$link['clicks'] + 1
            ]);
            break;
            
        default:
            // GET /api - Show API documentation
            if ($method !== 'GET') {
                json_response(['error' => 'Method not allowed. Use GET.'], 405);
            }
            
            json_response([
                'service' => 'URL Shortener API',
                'version' => '1.0',
                'description' => 'Free public API for URL shortening with no rate limits',
                'base_url' => $base_url . '/api',
                'endpoints' => [
                    'GET/POST /create' => [
                        'description' => 'Create a new short URL',
                        'examples' => [
                            'GET' => $base_url . '/api/create?url=https://example.com&slug=optional',
                            'POST JSON' => '{"url": "https://example.com", "slug": "optional"}',
                            'POST Form' => 'url=https://example.com&slug=optional'
                        ]
                    ],
                    'GET /info/{slug}' => [
                        'description' => 'Get information about a short URL',
                        'example' => $base_url . '/api/info/abc123'
                    ],
                    'GET /stats/{slug}' => [
                        'description' => 'Get detailed statistics for a short URL',
                        'example' => $base_url . '/api/stats/abc123'
                    ],
                    'GET /redirect/{slug}' => [
                        'description' => 'Get redirect data without actually redirecting',
                        'example' => $base_url . '/api/redirect/abc123'
                    ]
                ],
                'features' => [
                    'no_authentication' => 'No API keys required',
                    'no_rate_limits' => 'Unlimited requests',
                    'cors_support' => 'Can be used from any domain',
                    'preview_feature' => 'Add + to any short URL to preview destination'
                ]
            ]);
    }
}

/* ===== COOKIE FUNCTIONS ===== */
function save_url_to_cookie($slug, $url) {
    $saved_urls = [];
    if (isset($_COOKIE['shortened_urls'])) {
        $saved_urls = json_decode($_COOKIE['shortened_urls'], true);
    }
    
    array_unshift($saved_urls, [
        'slug' => $slug,
        'url' => $url,
        'created' => date('Y-m-d H:i:s'),
        'domain' => get_domain_from_url($url)
    ]);
    
    $saved_urls = array_slice($saved_urls, 0, 10);
    
    setcookie('shortened_urls', json_encode($saved_urls), time() + (86400 * 30), "/");
}

function get_saved_urls() {
    if (isset($_COOKIE['shortened_urls'])) {
        return json_decode($_COOKIE['shortened_urls'], true);
    }
    return [];
}

/* ===== CREATE LINK (Web Form) ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url']) && $path === '') {
    $url = trim($_POST['url']);
    $custom = trim($_POST['slug'] ?? "");

    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        die("<div class='error'>Invalid URL format</div>");
    }

    if ($custom) {
        if (!preg_match("/^[a-zA-Z0-9_-]+$/", $custom)) {
            die("<div class='error'>Slug can only contain letters, numbers, hyphens and underscores</div>");
        }
        $slug = $custom;
    } else {
        do {
            $slug = random_slug();
            $check = $conn->query("SELECT id FROM links WHERE slug='$slug'");
        } while ($check->num_rows > 0);
    }

    $stmt = $conn->prepare("INSERT INTO links (slug, url) VALUES (?, ?)");
    if (!$stmt) die("<div class='error'>Slug already exists</div>");
    $stmt->bind_param("ss", $slug, $url);
    
    if (!$stmt->execute()) {
        die("<div class='error'>Slug already exists. Try a different one.</div>");
    }

    save_url_to_cookie($slug, $url);
    
    $short_url = $base_url . '/' . $slug;
    $preview_url = $base_url . '/' . $slug . '+';
    $stats_url = $base_url . '/?stats=' . $slug;
    $api_url = $base_url . '/api/info/' . $slug;
    
    echo "<div class='success'>
            <h3>✅ Short URL Created!</h3>
            <div class='url-display'>
                <input type='text' id='shortUrl' value='$short_url' readonly>
                <button onclick='copyToClipboard(\"$short_url\")'>Copy</button>
            </div>
            <div class='preview-note'>
                <p>🔍 Add <code>+</code> to the end of the URL to see destination preview:</p>
                <div class='url-display'>
                    <input type='text' id='previewUrl' value='$preview_url' readonly>
                    <button onclick='copyToClipboard(\"$preview_url\")'>Copy</button>
                </div>
            </div>
            <p class='stats-link'>
                <a href='$stats_url' target='_blank'>📊 View Statistics</a>
            </p>
            <p class='api-note'>
                <small>⚡ API: <code>$api_url</code></small>
            </p>
            <p class='original-url'>
                Original: <a href='$url' target='_blank'>" . htmlspecialchars($url) . "</a>
            </p>
          </div>";
    exit;
}

/* ===== DESTINATION PREVIEW PAGE ===== */
// Check if URL ends with + (preview mode)
$is_preview = false;
$original_slug = '';
if (substr($path, -1) === '+') {
    $is_preview = true;
    $original_slug = rtrim($path, '+');
    
    $stmt = $conn->prepare("SELECT * FROM links WHERE slug=?");
    $stmt->bind_param("s", $original_slug);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($row = $res->fetch_assoc()) {
        $domain = get_domain_from_url($row['url']);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Redirecting to <?=htmlspecialchars($domain)?></title>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }
                
                body {
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    color: #e0e0e0;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    min-height: 100vh;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    padding: 20px;
                }
                
                .preview-container {
                    max-width: 600px;
                    width: 100%;
                    background: rgba(255, 255, 255, 0.05);
                    border-radius: 20px;
                    padding: 40px;
                    text-align: center;
                    border: 1px solid rgba(255, 255, 255, 0.1);
                    backdrop-filter: blur(10px);
                }
                
                .preview-icon {
                    font-size: 4rem;
                    margin-bottom: 20px;
                    color: #4cc9f0;
                }
                
                h1 {
                    color: #4cc9f0;
                    margin-bottom: 20px;
                    font-size: 2rem;
                }
                
                .url-display {
                    background: rgba(255, 255, 255, 0.08);
                    border-radius: 10px;
                    padding: 15px;
                    margin: 20px 0;
                    word-break: break-all;
                    text-align: left;
                }
                
                .url-display a {
                    color: #4cc9f0;
                    text-decoration: none;
                }
                
                .url-display a:hover {
                    text-decoration: underline;
                }
                
                .domain-badge {
                    display: inline-block;
                    background: rgba(76, 201, 240, 0.2);
                    color: #4cc9f0;
                    padding: 8px 16px;
                    border-radius: 20px;
                    margin: 15px 0;
                    font-weight: bold;
                }
                
                .buttons {
                    display: flex;
                    gap: 15px;
                    margin: 30px 0;
                    flex-wrap: wrap;
                    justify-content: center;
                }
                
                .btn {
                    padding: 15px 30px;
                    border-radius: 10px;
                    border: none;
                    font-weight: bold;
                    cursor: pointer;
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                    font-size: 1rem;
                }
                
                .btn-primary {
                    background: linear-gradient(45deg, #4cc9f0, #4361ee);
                    color: white;
                    flex: 1;
                    min-width: 150px;
                }
                
                .btn-secondary {
                    background: rgba(255, 255, 255, 0.1);
                    color: #e0e0e0;
                    flex: 1;
                    min-width: 150px;
                }
                
                .btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(76, 201, 240, 0.3);
                }
                
                .countdown {
                    font-size: 1.2rem;
                    margin: 20px 0;
                    color: #a0a0a0;
                }
                
                .countdown-number {
                    color: #4cc9f0;
                    font-weight: bold;
                    font-size: 1.5rem;
                }
                
                .warning {
                    background: rgba(231, 76, 60, 0.1);
                    border: 1px solid rgba(231, 76, 60, 0.3);
                    border-radius: 10px;
                    padding: 15px;
                    margin: 20px 0;
                    color: #e74c3c;
                }
                
                .info-box {
                    background: rgba(255, 255, 255, 0.05);
                    border-radius: 10px;
                    padding: 15px;
                    margin: 20px 0;
                    text-align: left;
                }
                
                @media (max-width: 768px) {
                    .preview-container {
                        padding: 25px;
                    }
                    
                    .buttons {
                        flex-direction: column;
                    }
                    
                    .btn {
                        width: 100%;
                    }
                }
            </style>
        </head>
        <body>
            <div class="preview-container">
                <div class="preview-icon">🔍</div>
                <h1>Link Destination Preview</h1>
                
                <div class="domain-badge">
                    <?=htmlspecialchars($domain)?>
                </div>
                
                <div class="url-display">
                    <strong>Destination:</strong><br>
                    <a href="<?=$row['url']?>" target="_blank" rel="noopener noreferrer">
                        <?=htmlspecialchars($row['url'])?>
                    </a>
                </div>
                
                <div class="warning">
                    ⚠️ <strong>Security Notice:</strong> Only proceed if you trust this link.
                </div>
                
                <div class="info-box">
                    <p><strong>Short URL:</strong> <?=$base_url?>/<?=$original_slug?></p>
                    <p><strong>Total Clicks:</strong> <?=$row['clicks']?></p>
                    <p><strong>Created:</strong> <?=date('M d, Y', strtotime($row['created_at']))?></p>
                    <p><strong>API Info:</strong> <a href="<?=$base_url?>/api/info/<?=$original_slug?>" style="color: #4cc9f0;">JSON Data</a></p>
                </div>
                
                <div class="countdown">
                    Auto-redirecting in <span class="countdown-number" id="countdown">5</span> seconds
                </div>
                
                <div class="buttons">
                    <button class="btn btn-primary" onclick="proceedToLink()">
                        ✅ Continue to Destination
                    </button>
                    <button class="btn btn-secondary" onclick="goBack()">
                        ⬅️ Go Back
                    </button>
                </div>
                
                <p style="color: #666; margin-top: 20px;">
                    This preview page shows where the shortened link redirects to.
                </p>
            </div>
            
            <script>
                let seconds = 5;
                const countdownElement = document.getElementById('countdown');
                let countdownInterval;
                
                function startCountdown() {
                    countdownInterval = setInterval(() => {
                        seconds--;
                        countdownElement.textContent = seconds;
                        
                        if (seconds <= 0) {
                            clearInterval(countdownInterval);
                            proceedToLink();
                        }
                    }, 1000);
                }
                
                function proceedToLink() {
                    clearInterval(countdownInterval);
                    window.location.href = "<?=$row['url']?>";
                }
                
                function goBack() {
                    clearInterval(countdownInterval);
                    window.history.back();
                }
                
                startCountdown();
            </script>
        </body>
        </html>
        <?php
        exit;
    }
}

/* ===== STATS PAGE ===== */
if (isset($_GET['stats'])) {
    $slug = $_GET['stats'];

    $stmt = $conn->prepare("SELECT * FROM links WHERE slug=?");
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $res = $stmt->get_result();
    if (!$link = $res->fetch_assoc()) die("<div class='error'>Link not found</div>");

    $days = [];
    $clicks = [];
    $q = $conn->query("SELECT day, clicks FROM click_stats WHERE link_id={$link['id']} ORDER BY day");
    while ($r = $q->fetch_assoc()) {
        $days[] = $r['day'];
        $clicks[] = $r['clicks'];
    }
    ?>
<!DOCTYPE html>
<html>
<head>
    <title>Stats for /<?=htmlspecialchars($slug)?></title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #e0e0e0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .header h1 {
            color: #4cc9f0;
            margin-bottom: 10px;
            font-size: 2.5rem;
        }
        
        .stats-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .preview-link {
            background: rgba(76, 201, 240, 0.1);
            border: 1px solid rgba(76, 201, 240, 0.3);
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .api-link {
            background: rgba(46, 204, 113, 0.1);
            border: 1px solid rgba(46, 204, 113, 0.3);
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        
        .stat-box {
            background: rgba(255, 255, 255, 0.08);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-box:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.12);
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
            color: #4cc9f0;
            margin: 10px 0;
        }
        
        .stat-label {
            color: #a0a0a0;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .chart-container {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 30px;
            margin: 30px 0;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 30px;
            background: linear-gradient(45deg, #4cc9f0, #4361ee);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .back-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(76, 201, 240, 0.4);
        }
        
        .url-display {
            background: rgba(255, 255, 255, 0.08);
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            word-break: break-all;
        }
        
        .original-url {
            color: #a0a0a0;
            font-size: 0.9rem;
        }
        
        .short-url-options {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin: 15px 0;
        }
        
        .short-url-options input {
            flex: 1;
            min-width: 200px;
            padding: 10px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 5px;
            color: white;
        }
        
        .short-url-options button {
            padding: 10px 20px;
            background: #4361ee;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 URL Statistics</h1>
            <p>Analytics for your shortened link</p>
        </div>
        
        <div class="stats-card">
            <h2 style="color: #4cc9f0; margin-bottom: 20px;">/<?=htmlspecialchars($slug)?></h2>
            
            <div class="preview-link">
                <p><strong>🔍 Destination Preview:</strong> Add <code>+</code> to the end of the URL to see where it redirects</p>
                <div class="short-url-options">
                    <input type="text" value="<?=$base_url?>/<?=$slug?>" id="shortUrl" readonly>
                    <button onclick="copyToClipboard('<?=$base_url?>/<?=$slug?>')">Copy</button>
                    <input type="text" value="<?=$base_url?>/<?=$slug?>+" id="previewUrl" readonly>
                    <button onclick="copyToClipboard('<?=$base_url?>/<?=$slug?>+')">Copy Preview URL</button>
                </div>
            </div>
            
            <div class="api-link">
                <p><strong>⚡ API Endpoints:</strong></p>
                <div class="short-url-options">
                    <input type="text" value="<?=$base_url?>/api/info/<?=$slug?>" id="apiInfoUrl" readonly>
                    <button onclick="copyToClipboard('<?=$base_url?>/api/info/<?=$slug?>')">Copy Info API</button>
                    <input type="text" value="<?=$base_url?>/api/stats/<?=$slug?>" id="apiStatsUrl" readonly>
                    <button onclick="copyToClipboard('<?=$base_url?>/api/stats/<?=$slug?>')">Copy Stats API</button>
                </div>
            </div>
            
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-label">Total Clicks</div>
                    <div class="stat-value"><?=$link['clicks']?></div>
                </div>
                
                <div class="stat-box">
                    <div class="stat-label">Created On</div>
                    <div class="stat-value" style="font-size: 1.5rem;"><?=date('M d, Y', strtotime($link['created_at']))?></div>
                </div>
            </div>
            
            <div class="url-display">
                <p><strong>Destination URL:</strong></p>
                <p><a href="<?=$link['url']?>" target="_blank" style="color: #4cc9f0;"><?=htmlspecialchars($link['url'])?></a></p>
            </div>
        </div>
        
        <?php if (!empty($days)): ?>
        <div class="chart-container">
            <h3 style="color: #4cc9f0; margin-bottom: 20px;">📈 Daily Click History</h3>
            <canvas id="chart" height="100"></canvas>
        </div>
        <?php else: ?>
        <div class="stats-card">
            <p style="text-align: center; color: #a0a0a0;">No click data available yet.</p>
        </div>
        <?php endif; ?>
        
        <div style="text-align: center;">
            <a href="/" class="back-link">🏠 Back to Home</a>
        </div>
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('✅ Copied to clipboard!');
            });
        }
        
        <?php if (!empty($days)): ?>
        new Chart(document.getElementById('chart'), {
            type: 'line',
            data: {
                labels: <?=json_encode($days)?>,
                datasets: [{
                    label: 'Clicks per day',
                    data: <?=json_encode($clicks)?>,
                    borderColor: '#4cc9f0',
                    backgroundColor: 'rgba(76, 201, 240, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: {
                            color: '#e0e0e0'
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#a0a0a0'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#a0a0a0'
                        }
                    }
                }
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>
<?php exit; }

/* ===== REDIRECT ===== */
if ($path !== "" && !$is_preview && strpos($path, 'api') !== 0) {
    $stmt = $conn->prepare("SELECT * FROM links WHERE slug=?");
    $stmt->bind_param("s", $path);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        $conn->query("UPDATE links SET clicks = clicks + 1 WHERE id={$row['id']}");

        $today = date("Y-m-d");
        $conn->query("
        INSERT INTO click_stats (link_id, day, clicks)
        VALUES ({$row['id']}, '$today', 1)
        ON DUPLICATE KEY UPDATE clicks = clicks + 1
        ");

        header("Location: ".$row['url'], true, 302);
        exit;
    }

    http_response_code(404);
    die("<div class='error'>Link not found</div>");
}

/* ===== MAIN PAGE ===== */
$saved_urls = get_saved_urls();
?>
<!DOCTYPE html>
<html>
<head>
    <title>URL Shortener</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #e0e0e0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 50px;
            padding: 30px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .header h1 {
            color: #4cc9f0;
            font-size: 3rem;
            margin-bottom: 10px;
            text-shadow: 0 2px 10px rgba(76, 201, 240, 0.3);
        }
        
        .header p {
            color: #a0a0a0;
            font-size: 1.1rem;
        }
        
        .feature-note {
            background: rgba(76, 201, 240, 0.1);
            border: 1px solid rgba(76, 201, 240, 0.3);
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
            text-align: center;
        }
        
        .feature-note code {
            background: rgba(0, 0, 0, 0.3);
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
        }
        
        .card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #a0a0a0;
            font-weight: 500;
        }
        
        input {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.08);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        input:focus {
            outline: none;
            border-color: #4cc9f0;
            box-shadow: 0 0 0 3px rgba(76, 201, 240, 0.2);
        }
        
        input::placeholder {
            color: #666;
        }
        
        button {
            background: linear-gradient(45deg, #4cc9f0, #4361ee);
            color: white;
            border: none;
            padding: 16px 40px;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            width: 100%;
        }
        
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(76, 201, 240, 0.4);
        }
        
        .success {
            background: rgba(46, 204, 113, 0.1);
            border: 1px solid rgba(46, 204, 113, 0.3);
            border-radius: 15px;
            padding: 30px;
            margin: 30px 0;
        }
        
        .error {
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid rgba(231, 76, 60, 0.3);
            border-radius: 15px;
            padding: 20px;
            margin: 20px 0;
            color: #e74c3c;
        }
        
        .url-display {
            display: flex;
            gap: 10px;
            margin: 20px 0;
        }
        
        .url-display input {
            flex: 1;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .url-display button {
            width: auto;
            padding: 15px 25px;
            background: #4361ee;
        }
        
        .preview-note {
            background: rgba(76, 201, 240, 0.1);
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
        }
        
        .preview-note code {
            background: rgba(0, 0, 0, 0.3);
            padding: 2px 6px;
            border-radius: 4px;
        }
        
        .api-note {
            color: #10b981;
            font-size: 0.9rem;
            margin: 10px 0;
        }
        
        .api-note code {
            background: rgba(16, 185, 129, 0.2);
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
        }
        
        .stats-link {
            margin: 15px 0;
        }
        
        .stats-link a {
            color: #4cc9f0;
            text-decoration: none;
            font-weight: bold;
        }
        
        .original-url {
            color: #a0a0a0;
            font-size: 0.9rem;
            margin-top: 10px;
        }
        
        .history-section {
            margin-top: 50px;
        }
        
        .history-section h3 {
            color: #4cc9f0;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .history-list {
            display: grid;
            gap: 15px;
        }
        
        .history-item {
            background: rgba(255, 255, 255, 0.03);
            border-radius: 10px;
            padding: 15px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .history-item:hover {
            background: rgba(255, 255, 255, 0.05);
        }
        
        .history-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .history-slug {
            color: #4cc9f0;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .history-domain {
            background: rgba(76, 201, 240, 0.1);
            color: #4cc9f0;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
        }
        
        .history-url {
            color: #a0a0a0;
            font-size: 0.9rem;
            margin-bottom: 10px;
            word-break: break-all;
        }
        
        .history-date {
            color: #666;
            font-size: 0.8rem;
            margin-bottom: 10px;
        }
        
        .history-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .history-actions button {
            padding: 8px 15px;
            font-size: 0.9rem;
            background: rgba(255, 255, 255, 0.1);
            width: auto;
        }
        
        .history-actions .preview-btn {
            background: rgba(76, 201, 240, 0.2);
        }
        
        .history-actions .api-btn {
            background: rgba(46, 204, 113, 0.2);
        }
        
        .footer {
            text-align: center;
            margin-top: 50px;
            color: #666;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            
            .header h1 {
                font-size: 2.2rem;
            }
            
            .card {
                padding: 25px;
            }
            
            .history-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .history-actions {
                width: 100%;
            }
            
            .history-actions button {
                flex: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔗 me.xo.je</h1>
            <p>Shorten your links quickly and securely by ExploitZ3r0</p>
            
            <div class="feature-note">
                <p>⚡ <strong>API:</strong> Use <code><?=$base_url?>/api</code> (GET & POST supported)</p>
            </div>
        </div>
        
        <div class="card">
            <h2 style="color: #4cc9f0; margin-bottom: 25px; text-align: center;">Create Short URL</h2>
            
            <form method="post" id="urlForm">
                <div class="form-group">
                    <label for="url">📎 Destination URL</label>
                    <input type="url" name="url" id="url" placeholder="https://example.com" required>
                </div>
                
                <div class="form-group">
                    <label for="slug">✏️ Custom Slug (Optional)</label>
                    <input type="text" name="slug" id="slug" placeholder="my-custom-link" maxlength="32">
                    <small style="color: #666; display: block; margin-top: 5px;">Leave empty for auto-generated slug</small>
                </div>
                
                <button type="submit" id="submitBtn">✨ Create Short URL</button>
            </form>
            
            <div id="result"></div>
        </div>
        
        <?php if (!empty($saved_urls)): ?>
        <div class="history-section">
            <h3>📚 Recently Created URLs</h3>
            <div class="history-list">
                <?php foreach ($saved_urls as $item): ?>
                <div class="history-item">
                    <div class="history-header">
                        <div>
                            <span class="history-slug">/<?=htmlspecialchars($item['slug'])?></span>
                            <?php if (!empty($item['domain'])): ?>
                            <span class="history-domain"><?=htmlspecialchars($item['domain'])?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="history-url"><?=htmlspecialchars($item['url'])?></div>
                    <div class="history-date">Created: <?=$item['created']?></div>
                    <div class="history-actions">
                        <button onclick="copyToClipboard('<?=$base_url?>/<?=$item['slug']?>')">Copy Link</button>
                        <button class="preview-btn" onclick="copyToClipboard('<?=$base_url?>/<?=$item['slug']?>+')">Copy Preview URL</button>
                        <a href="?stats=<?=$item['slug']?>" target="_blank">
                            <button style="background: #4cc9f0;">Stats</button>
                        </a>
                        <a href="<?=$base_url?>/api/info/<?=$item['slug']?>" target="_blank">
                            <button class="api-btn">API</button>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="footer">
            <p>🔒 No IP tracking • ⚡ API (GET & POST) • 🔍 Destination preview • 🚫 No rate limits</p>
        </div>
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('✅ Copied to clipboard!');
            });
        }
        
        document.getElementById('urlForm').addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.innerHTML = '⏳ Creating...';
            submitBtn.disabled = true;
            
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(html => {
                document.getElementById('result').innerHTML = html;
                submitBtn.innerHTML = '✨ Create Short URL';
                submitBtn.disabled = false;
                document.getElementById('urlForm').reset();
                
                setTimeout(() => {
                    location.reload();
                }, 2000);
            })
            .catch(error => {
                console.error('Error:', error);
                submitBtn.innerHTML = '✨ Create Short URL';
                submitBtn.disabled = false;
            });
        });
        
        document.getElementById('url').addEventListener('blur', function() {
            const slugField = document.getElementById('slug');
            if (!slugField.value && this.value) {
                try {
                    const url = new URL(this.value);
                    let slug = url.hostname.replace('www.', '').split('.')[0];
                    slug = slug.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase();
                    slugField.placeholder = slug;
                } catch (e) {
                    // Invalid URL, skip
                }
            }
        });
    </script>
</div>
<div class="col-12 col-lg-auto mt-3 mt-lg-0">
                            <ul class="list-inline list-inline-dots mb-0">
                                <li class="list-inline-item">
                                    Copyright © 
                                    <a href="https://bin.base44.app/">ExploitZ3r0</a>
                                    All rights reserved.
                                </li>
                            </ul>
                        </div>
     <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                            <ul class="list-inline list-inline-dots mb-0">
                                    <a href="https://me.xo.je/terms.php">Terms</a>
                                </li>
                            </ul>
                        </div>
</body>
</html>