<?php
// terms.php – me.xo.je Terms & Conditions
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Terms & Conditions – me.xo.je</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #0f1115;
            color: #eaeaea;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        h1, h2 {
            color: #ffffff;
        }
        h1 {
            border-bottom: 2px solid #2a2d35;
            padding-bottom: 10px;
        }
        h2 {
            margin-top: 30px;
        }
        ul {
            margin-left: 20px;
        }
        li {
            margin-bottom: 8px;
        }
        footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #2a2d35;
            font-size: 0.9em;
            color: #b0b0b0;
        }
        a {
            color: #4da3ff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>me.xo.je – Terms & Conditions</h1>

    <p>
        We’ve tried to make our terms as clear and easy to read as possible,
        without unnecessary legal language.
    </p>

    <p>
        By using <strong>me.xo.je</strong>, you agree to the following Terms & Conditions.
    </p>

    <h2>1. Forbidden Activities</h2>
    <p><strong>me.xo.je may NOT be used</strong> to create shortened URLs that:</p>
    <ul>
        <li>Are used in commercial, bulk, or mass email campaigns</li>
        <li>Are used for unsolicited advertising (spam), including email, forums, SMS, or social networks</li>
        <li>Link to malicious or harmful content such as phishing, viruses, trojans, adware, or malware</li>
        <li>Link to any form of child sexual abuse material</li>
        <li>Link to other URL shortening or redirection services (link chains)</li>
        <li>Link to content that infringes copyright or intellectual property rights</li>
        <li>Link to unethical or deceptive content, including:
            <ul>
                <li>“Get rich quick” schemes</li>
                <li>Pyramid or Ponzi schemes</li>
                <li>Paid “self-help” scams</li>
                <li>Fake or misleading competitions</li>
                <li>Paid survey websites</li>
                <li>Services that encourage spamming others</li>
            </ul>
        </li>
    </ul>

    <h2>2. Legal Use</h2>
    <p>
        All use of <strong>me.xo.je</strong> and any content linked through the service
        must be legal under applicable laws and regulations.
    </p>

    <h2>3. URL Rejection and Removal</h2>
    <p>
        We reserve the right to reject, disable, redirect, or remove any shortened URL
        at any time, with or without notice, for any reason.
    </p>
    <p>
        This includes violations of these Terms, suspected abuse, security concerns,
        or listings on spam or malware blacklists.
    </p>

    <h2>4. Shortened URLs</h2>
    <ul>
        <li>Shortened URLs cannot be deleted or modified after creation</li>
        <li>This policy helps prevent abuse and malicious behavior</li>
        <li>Shortened URLs may redirect anywhere — you follow them at your own risk</li>
        <li>me.xo.je is not responsible or liable for external website content</li>
    </ul>

    <h2>5. Data Usage</h2>
    <ul>
        <li>We do not sell or share user data with third parties unless required by law</li>
        <li>We collect only minimal data required to operate the service and prevent abuse</li>
    </ul>

    <h2>6. Warranty and Liability</h2>
    <p><strong>Short version:</strong> me.xo.je is free and provided as-is.</p>
    <p>
        We provide the service without warranties of any kind. We are not liable for
        any loss, damage, downtime, slow performance, data loss, or removed links.
    </p>

    <h2>7. Violation of Terms</h2>
    <p>
        If you violate these Terms, we may disable shortened URLs or block access to
        the service temporarily or permanently.
    </p>
    <p>
        Severe abuse or illegal activity may be reported to relevant authorities.
    </p>

    <footer>
        © <?php echo date('Y'); ?> me.xo.je — All rights reserved.
    </footer>
</div>

</body>
</html>
